export default function CircleLoader() {
  return <div id="circle-loader" className="circleLoader"></div>;
}
