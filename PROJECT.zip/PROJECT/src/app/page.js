import Browse from "./browse/page";

export default function Home() {
  return <Browse />;
}
